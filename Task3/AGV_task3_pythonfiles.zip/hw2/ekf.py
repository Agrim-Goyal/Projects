import numpy as np

from utils import minimized_angle

from soccer_field import Field

class ExtendedKalmanFilter:
    def __init__(self, mean, cov, alphas, beta):
        self.alphas = alphas
        self.beta = beta

        self._init_mean = mean
        self._init_cov = cov
        self.reset()

    def reset(self):
        self.mu = self._init_mean
        self.sigma = self._init_cov

    def update(self, env, u, z, marker_id):
        """Update the state estimate after taking an action and receiving a landmark
        observation.

        u: action
        z: landmark observation
        marker_id: landmark ID
        """
        mu_bar=Field.forward(env,self.mu,u)
        G=Field.G(env,self.mu,u)
        G_tr=np.transpose(G)
        p=np.matmul(G,self.sigma)
        p=np.matmul(p,G_tr)
        V=Field.V(env,self.mu,u)
        V_tr=np.transpose(V)
        R=Field.noise_from_motion(env,u,self.alphas)
        R=np.matmul(V,R)
        R=np.matmul(R,V_tr)
        sigma_bar=np.add(p,R)
        H=Field.H(env,mu_bar,marker_id)
        H_tr1=np.transpose(H)
        H_tr=H_tr1.reshape(-1,1)
        v=np.matmul(H,sigma_bar)
        v=np.matmul(v,H_tr)
        v=np.add(v,self.beta)
        v=np.linalg.inv(v)
        K=np.matmul(sigma_bar,H_tr)
        K=np.matmul(K,v)
        r=minimized_angle(np.subtract(z,Field.observe(env,mu_bar,marker_id)))
        r=np.matmul(K,r)
        self.mu=np.add(mu_bar,r)
        self.sigma=np.subtract(np.identity(3),np.matmul(K,H))
        self.sigma=np.matmul(self.sigma,sigma_bar)
        self.mu = np.ravel(self.mu).astype(float).reshape(-1,1)
        # YOUR IMPLEMENTATION HERE
        return self.mu, self.sigma
